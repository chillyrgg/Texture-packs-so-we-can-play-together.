Sapixcraft 
By Sapix


Join the Sapixcraft Discord community:
http://bit.ly/2kZrff0


Official Website:
http://sapixcraft.com


Terms of Use:
https://sapixcraft.com/legal/


If you downloaded this texture pack from anywhere 
other than Sapixcraft.com website, please inform us
at: <contact@sapixcraft.com> You may not get a response,
but it provides me with valuable feedback to ensure
ower work isn't being illegally stolen for profit.


Proper credit given to 'Sapix' as well as referring to the http://sapixcraft.com website 
(using a non-profit direct link) is greatly appreciated and recommended when using the content
of the 'Sapixcraft' resource pack in:
	* Let's play 
	* Showcase video
	* Video' in general
	* Blog
	* Forum
	* Etc.
	
	
� 2019, Sapixcraft http://sapixcraft.com